<?php 
defined('BASEPATH') or exit('No direct script access allowed');

class Menu_model extends CI_Model
{
    public function getSubMenu()
    {
        $query = "SELECT `use_sub_menu`.*, `use_menu`.`menu`
                  FROM `use_sub_menu` JOIN `use_menu`
                  ON `use_sub_menu`.`menu_id` = `use_menu`.`id`
                ";
        return $this->db->query($query)->result_array();
    }
}
