                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>
                    <!DOCTYPE html>
                        <html>
                        <head>
                        <title>Form Upload File - CodeIgniter 3</title>
                        </head>
                        <body>
                        <h2>Form Upload File</h2>
                        <?php echo form_open_multipart('upload/do_upload'); ?>
                            <input type="file" name="userfile" size="20" required />
                            <br /><br />
                            <input type="submit" value="Upload" />
                        <?php echo form_close(); ?>
                        </body>
                        </html>
                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->            